var com = com || {};
		com.o2GEEK = com.o2GEEK || {};

com.o2GEEK.gQ = function( selector, context){
	// ... 
}

com.o2GEEK.gQ.loadJS = function (){
	//...
}