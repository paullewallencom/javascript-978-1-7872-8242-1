var aNames,
		oCarType,
		ctChevy = new CarType(); //ct - CarType

function getName(){

}