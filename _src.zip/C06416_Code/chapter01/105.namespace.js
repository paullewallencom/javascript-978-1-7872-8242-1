/* anml - Animal */

var anmlCat = new com.o2GEEK.Animal('cat');

var com = com || {};
		com.o2GEEK = com.o2GEEK || {};


var com.o2GEEK.Animal = function(type){

}

com.o2GEEK.Animal.prototype.version = '1.00';
