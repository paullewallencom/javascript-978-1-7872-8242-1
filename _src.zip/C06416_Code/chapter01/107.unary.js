/* anml - Animal */

var anmlCat = new Animal('cat');

function Animal(type){

}

Animal.prototype.version = '1.00';
