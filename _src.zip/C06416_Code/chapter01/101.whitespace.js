var name	=	'Ben' ,
		sur		=	'Fhala',
		i 		=	0;

if( a > b ){
	doSomething();
}

for ( ; i<100 ; i++ ){
	doSomething();
}
