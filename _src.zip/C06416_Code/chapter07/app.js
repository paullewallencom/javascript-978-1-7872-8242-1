var config = require('./geo.js');
console.log(config.user);
