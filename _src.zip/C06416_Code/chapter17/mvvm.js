class PageModel {
}
class User {
}
