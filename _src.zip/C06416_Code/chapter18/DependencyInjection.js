class UserManager {
    constructor(database, userEmailer) {
        this.database = database;
        this.userEmailer = userEmailer;
    }
}
class Database {
}
class UserEmailer {
}
